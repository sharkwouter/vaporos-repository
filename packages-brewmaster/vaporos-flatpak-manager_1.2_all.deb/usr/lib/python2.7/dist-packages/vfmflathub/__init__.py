from vfmflathub.api import get_applications
from vfmflathub.application import Application
from vfmflathub.flatpak import add_flathub, get_installed_applications, install, uninstall
