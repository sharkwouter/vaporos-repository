from pyftpdlib import _depwarn

_depwarn("pyftpdlib.contrib namespace is deprecated")
